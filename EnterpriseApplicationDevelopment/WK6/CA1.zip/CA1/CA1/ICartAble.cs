﻿/* X-Number: X00119025
 * Date: 19/10/2017
 */

namespace CA1
{
    interface ICartAble
    {
        string Code { get; }                                    //Properties
        string Description { get; }
        double Price { get; }
    }
}
