' 2 entry points
' e.g. vbc Main.vb /main:Main1

Public Module Main1

	Sub Main()
		System.Console.WriteLine("in Main1")
	End Sub
	
End Module


Public Module Main2

	Sub Main()
		System.Console.WriteLine("in Main2")
	End Sub
	
End Module