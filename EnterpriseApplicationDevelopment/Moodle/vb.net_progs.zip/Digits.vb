REM Control-flow VB.Net style
REM loop thru digits displaying them and whether they are odd or even


Class Digits
	Inherits System.Object

	' default constructor provided automatically if none coded

	' 2 constants
	Private Const LOW = 0			' assumed Shared (i.e. static in C#)
	Private Const HIGH = 9
	
	' display using a for next loop
	Sub Display1()
	
		Dim i as Integer
	
		For i = LOW to HIGH				' step 1
			
			If i Mod 2 = 0 Then			' = is comparison
				System.Console.WriteLine("even: " & i)
			Else
				System.Console.WriteLine("odd: " & i)
			End If
			
			' No Begin....End
		Next
	
	End Sub
	
	' display using a do until loop having stored them in an array
	Sub Display2()
		
			' an array
			Dim digits() as Integer = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9}
			
			Dim i as Integer = 0			' declare & initialise
		
			Do Until i = digits.Length		' array length (property)
				
				If digits(i) Mod 2 = 0 Then	' = is comparison
					System.Console.WriteLine("even: " & i)				
				Else
					System.Console.WriteLine("odd: " & i)
				End If
				
				i += 1
			Loop					' no ++ or --
		
	End Sub

End Class


' driver module
Module Driver
  
   Sub Main()							' Main sub
      
      Dim d as Digits
      
      d = New Digits()
      d.Display1()
      System.Console.WriteLine()				' blank line
      d.Display2()
      
   End Sub
   
 
End Module