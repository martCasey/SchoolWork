REM Demo of properties

' Person has a name and age
Class Person
	Inherits System.Object

	' auto initialization
	Private _name as String				' = "" implied
	Private _age as Integer				' = 0 implied
	
	' property to correspond to _name, no naming restrictions
	' name and Name are same thing as not case sensitive !
	Property Name() as String			' read/write
	
		Get
			Return _name
		End Get
	
		Set (Value as String)			' implied ByVal
			_name = Value			' "Value"
		End Set
	
	End Property
	
	' constructor
	Sub New(Name as String, Age as Integer)
		me.Name = Name				' calls Set
		me._age = Age
	End Sub
	
	' no default constructor

End Class


' driver module
Module Driver
  
   Sub Main()							' Main sub
      
     Dim p as Person = New Person("Gary", 21)
     p.Name = "Gaz"
     System.Console.WriteLine(p.Name)				' no Imports as top
     
   End Sub
   
 
End Module