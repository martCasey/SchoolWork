Imports System

' Demo of polymorphism, a dog isa Dog and a Mammal too

NameSpace AnimalKingdom

Public MustInherit Class Mammal						' abstract class

	Private _name as String						' Public, Protected, Friend (same program file), Protected Friend, Private
	
	' read only property
	Public ReadOnly Property Name() as String			' no necessity for property name to correspond to mem var
	
		Get
			 return _name
		End Get
	
	End Property
	
	Public Overridable Sub MakeSound()				' can be overriden, all methods are virtual by default in VB.Net
		Console.WriteLine(Name & " makes a mammal sound")
	End Sub
	
	' constructor
	Sub New(ByVal Name as String)
		me._name = Name						' not case sensitive
	End Sub
	
End Class

'A Dog isa Mammal, cannot make access less restrictive in subclass
Public Class Dog						' Friend Dog = > not accessible outside this program file
	Inherits Mammal						' isa Mammal
	
	
	Public Overrides Sub MakeSound()
		Console.WriteLine(Name & " makes a sound: bow wow!")
	End Sub							'Name is an inherited property
	
	'constructor
	Sub New(ByVal dogName as String)
		MyBase.New(dogName)				' call superclass constructor
	End Sub

	'no default constructor
	
End Class

End NameSpace


' driver module
Module Driver
  
   Sub Main()							' Main sub
   
   	Dim m as AnimalKingdom.Mammal				' base class reference
   	m = New AnimalKingdom.Dog("Pluto")			' subclass instance
   	m.MakeSound()						' polymorphic call

	'm = Nothing						' null
     
   End Sub
   
End Module