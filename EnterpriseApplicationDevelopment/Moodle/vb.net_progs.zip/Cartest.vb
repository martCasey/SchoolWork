Imports Garage

'test class for Car
'vbc CarTest.vb /reference:Car.dll


Module CarTest

   Sub Main()						' the Main procedure
      
      Dim c as Car
      c = New Car("Alfa Romeo","1.8 TSpark","99 D 16999")
      System.Console.WriteLine(c)			' ToString
   
   End Sub

End Module