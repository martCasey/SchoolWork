Imports MicroSoft.VisualBasic					' VB run-time library namespace

' Hello World VB.Net style.

' no class in this example, just a module with 1 procedure and 1 function

Module HelloWorld2

   ' several variants of Main() exist:
   ' i.e. 	Sub Main()
   ' or 	Sub Main(ByVal CmdArgs() As String)
   ' or 	Function Main() As Integer
   ' or 	Function Main(ByVal CmdArgs() As String) As Integer
   
   'Functions return values
   'Procedure (Sub) dont return values
   
   Sub Main()							' Main procedure
      
      Dim x as Integer
      
      x = Hello()						' Function call
      System.Console.WriteLine("x is: " & x)			' not ,
      
   End Sub
   
   ' Hello function can be called from anywhere in the project
   Function Hello() as Integer					' Integer return type
   
   	 Dim response As String
         
         response = MsgBox("Hello there VB.Net World !", MsgBoxStyle.OKCancel)	
         
         ' or Microsoft.VisualBasic.MsgBox
         
         If response = MsgBoxResult.Ok Then			' OK pressed
         	Return 0
         Else
         	Return 1					' Cancel pressed
      	End If
      
   End Function
   
  

End Module