Imports System							'using in C#


REM Hello World VB.Net style.

' VB.Net is not case sensitive !
' You can do almost everything in VB.Net that you can do in C# (except operator overloading, XML comments etc.)

' no class in this example, just a module, in default namespace
' module allows us to code outside of a class

Module HelloWorld1						' doesnt have to be same name as file

   Public Sub Main()						' Main procedure, Friend is default (assembly)
      Console.WriteLine("Hello there VB.Net World !")		' System.Console.WriteLine....
   End Sub							' End or end

End Module


