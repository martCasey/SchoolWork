Imports System

REM Car.vb
' vbc /target:library Car.vb

' no XML comments

Namespace Garage

' a car has a make, model and registration

Public Class Car				' Friend is default visibility for classes (internal in C#)
	Inherits System.Object			' Inherits keyword needs to be on a new line, implicit

	Private Make as String			' field
	Private Model as String			' private is default for fields and constants
	Private Registration as String
	
	' subs and functions are Public by default
	
	' constructor with 3 passed by value parameters, ByVal is default
	Public Sub New(Make as String, ByVal Model as String, ByVal Registration as String)
	
		me.Make = Make			' this in C#
		me.Model = Model
		me.Registration = Registration
	
	End Sub
	
	
	' default constructor
	Public Sub New()			' constructor name in New(...)
		Me.New("","","")		' MyClass an alternative, chained constructor call
	End Sub
	
	
	' destructor
	Overrides Protected Sub Finalize()
		System.Console.WriteLine("destructing " & Me.ToString())
	End Sub
	
	
	' override of inherited function from Object
	Overrides Public Function ToString() as String
		return "Make: " & Make & " Model: " & Model & " Registration: " & Registration
	End Function

End Class

End Namespace

' ps no operator overloading in VB.Net