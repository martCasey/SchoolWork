function EmailToFriend()
{
window.location = "mailto:"+"?subject=I thought this link might interest you." + "&body= From Site: www.visualbasicexpert.com Section: "+document.title+" Link: "+window.location;
}


