<!-- use this comment tag to hide the enclosed code from old browsers.

//Look for a version of Internet Explorer that supports ActiveX (i.e., one that's
//running on a platform other than Mac or Windows 3.1) or a browser that supports
//the plugin property of the navigator object and that has Flash Player 2.0
//installed.

if ((navigator.appName == "Microsoft Internet Explorer" &&
    navigator.appVersion.indexOf("Mac") == -1 &&   navigator.appVersion.indexOf("3.1") == -1) ||

    (navigator.plugins && navigator.plugins["Shockwave Flash"])
                       || navigator.plugins["Shockwave Flash 2.0"]){

   //Load a pre-defined HTML page with Flash Player in it into the browser window.
   //window.location='flashed.html';
}
else {
    //Load a pre-defined HTML page without Flash Player into the browser window.
    window.location='nonflashed.html';
}

// Close the comment tag. -->
