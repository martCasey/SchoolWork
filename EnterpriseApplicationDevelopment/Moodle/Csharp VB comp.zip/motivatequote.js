
var quotes=new Array()

//change the quotes if desired. Add/ delete additional quotes as desired.

quotes[0]='There are some people who live in a dream world, and there are some who face reality; and then there are those who turn one into the other. <p><i>-By Douglas Everett</i></p>'

quotes[1]='Whether you think you can or whether you think you can\'t, you\'re right! <p><i>-Henry Ford</i></p>'

quotes[2]='I know of no more encouraging fact than the unquestionable ability of man to elevate his life by conscious endeavor. <p><i>-Henry David Thoreau</i></p>'

quotes[3]='Do not let what you cannot do interfere with what you can do. <p><i>-John Wooden</i></p>'

quotes[4]='Accept everything about yourself - I mean everything, You are you and that is the beginning and the end - no apologies, no regrets. <p><i>-Clark Moustakas</i></p>'

quotes[5]='We must accept life for what it actually is - a challenge to our quality without which we should never know of what stuff we are made, or grow to our full stature. <p><i>-Ida R. Wylie</i></p>'

quotes[6]='High achievement always takes place in the framework of high expectation. <p><i>-Jack Kinder</i></p>'

quotes[7]='The measure of a man is the way he bears up under misfortune. <p><i>-Plutarch</i></p>'

quotes[8]='Don\'t wait for your ship to come in, swim out to it. <p><i>-Anon</i></p>'

quotes[9]='As I grow older, I pay less attention to what men say. I just watch what they do. <p><i>-Andrew Carnegie</i></p>'

quotes[10]='No steam or gas ever drives anything until it is confined. No Niagara is ever turned into light and power until it is tunneled. No life ever grows until it is focused, dedicated, disciplined. <p><i>-Harry Emerson Fosdick</i></p>'

quotes[11]='The words printed here are concepts. You must go through the experiences. <p><i>-Carl Frederick</i></p>'

quotes[12]='Man cannot discover new oceans unless he has the courage to lose sight of the shore. <p><i>-Andre Gide</i></p>'

quotes[13]='The wise man does at once what the fool does finally. <p><i>-Baltasar Gracian</i></p>'

quotes[14]='The world has the habit of making room for the man whose actions show that he knows where he is going. <p><i>-Napoleon Hill</i></p>'

quotes[15]='Success seems to be connected with action. Successful men keep moving. They make mistakes, but they don\'t quit. <p><i>-Conrad Hilton</i></p>'

quotes[16]='Do the things you know, and you shall learn the truth you need to know. <p><i>-George Macdonald</i></p>'

quotes[17]='I have never heard anything about the resolutions of the apostles, but a good deal about their acts. <p><i>-Horace Mann</i></p>'

quotes[18]='Let us not be content to wait and see what will happen, but give us the determination to make the right things happen. <p><i>-Peter Marshall</i></p>'

quotes[19]='I hear and I forget, I see and I remember. I do and I understand. <p><i>-Chinese Proverb</i></p>'

quotes[20]='One may walk over the highest mountain one step at a time. <p><i>-John Wanamaker</i></p>'

quotes[21]='Every action is either strong or weak, and when every action is strong we are successful. <p><i>-Wallace D. Wattles</i></p>'

quotes[22]='If we do what is necessary, all the odds are in our favor. <p><i>-Henry Kissinger</i></p>'

quotes[23]='Little minds are tamed and subdued by misfortune; but great minds rise above them. <p><i>-Washington Irving</i></p>'

quotes[24]='When an affliction happens to you, you either let it defeat you, or you defeat it... <p><i>-Rosalind Russell</i></p>'

quotes[25]='There\'s a basic human weakness inherent in all people which tempts them to want what they can\'t have and not want what is readily available to them. <p><i>-Robert J. Ringer</i></p>'

quotes[26]='If there is something to gain and nothing to lose by asking, by all means ask! <p><i>-W. Clement Stone</i></p>'

quotes[27]='It\'s not the situation ... It\'s your reaction to the situation <p><i>-Robert Conklin</i></p>'

quotes[28]='Life at any time can become difficult: life at any time can become easy.  It all depends upon how one adjusts oneself to life. <p><i>-Morarji Desai</i></p>'

quotes[29]='What happens is not as important as how you react to what happens. <p><i>-Thaddeus Golas</i></p>'

quotes[30]='To hell with circumstances; I create opportunities. <p><i>-Bruce Lee</i></p>'

var whichquote=Math.floor(Math.random()*(quotes.length))
document.write(quotes[whichquote])
